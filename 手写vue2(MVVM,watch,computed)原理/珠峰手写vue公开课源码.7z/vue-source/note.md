## Vue的两大核心点MVVM和DOM-diff
- vue中如何实现数据劫持
- 数组的劫持
- vue中的观察者模式
- 计算属性和watch的区别 (原理)
- vue中数据的批量更新
- nextTick原理
- 什么是虚拟dom及虚拟dom的作用
- vue中的diff实现

咱们九点半正式开始 上午9.30 - 12：00 下午是 2点到5点 课堂id：367589